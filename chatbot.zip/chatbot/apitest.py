import json
import requests
import yaml
from openpyxl import *
import csv
import os
BASE_PATH=r'C:\workspace\qiye\zhuanli\CTP_Chatbot\chatbot\testdata'
PATH=os.path.join(BASE_PATH,'config.yaml')
class Request_Api:
    def __init__(self):
        with open(PATH,'r',encoding='utf-8') as f:
            self.yaml_data=yaml.load(f)
            self.url=self.yaml_data['environment']['url']
            self.content_type=self.yaml_data['environment']['Content-Type']
            self.header={'Content-Type': self.content_type}
    def post_url(self,route,data):
            api_url=self.url+route
            try:
                response=requests.post(api_url,headers=self.header,json=data)
                return response
            except Exception as e:
                return e
    def get_url(self,route,data):
        try:
            api_url=self.url+route
            reponse=requests.get(api_url,headers=self.header,params=data)
            return reponse
            print (reponse)
        except Exception as e:
            return e
    def put_url(self,route,data):
        try:
            api_url=self.url+route
            reponse=requests.put(api_url,headers=self.header,json=data)
            return reponse
        except Exception as e:
            return e
    def delete_url(self,route,tenanid,lang):
        try:
            api_url=self.url+route+tenanid+'/'+lang
            print(api_url)
            reponse=requests.delete(api_url)
            return reponse
        except Exception as e:
            return e
    def check_response(self,response):
        content=json.loads(response.text)
        return [response.status_code,content['msg']]
    def read_xlsx(self,response,path,sheetname):
        response=self.check_response(response)
        if len(response)==2:
            code=response[0]
            msg=response[1]
            wb=load_workbook(path)
            wls=wb[sheetname]
            rows=wls.rows
            for i in rows:
                if code == i[0].value:
                    return i[1].value
                    break
                else:
                    continue
        else:
            return('接口连接错误')
    def read_json(self,path):
        with open(path,encoding='utf-8') as f:
            bodys=json.load(f)
        return bodys


