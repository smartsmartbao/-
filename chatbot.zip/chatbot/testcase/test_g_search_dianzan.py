import unittest
from apitest import *
import yaml
import time
from report import HTMLTestRunner
import os
path=os.path.join(BASE_PATH,'testcase_searchdianzan.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testsearchdizan(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route=Yaml_Data['search_dianzan_api']['route']
        self.api=Request_Api()
    @staticmethod
    def getsearchdizan(i,cases):
        def func(self):
            body=cases[i]
            msg = body['msg']
            with open(os.path.join(BASE_PATH,'answer.csv'),'r',encoding='utf-8') as f:
                csv_file=csv.reader(f)
                for row in csv_file:
                    messsgeid=row[0]
                    timestamp=float(int(row[1])/1000)
                    dt=time.strftime('%Y-%m-%d',time.localtime(timestamp))
                    break
                if body['tenantId']!="" and body['startDate']!="" and body['endDate']!="":
                    para={"tenantId":body["tenantId"],"startDate":dt,"endDate":dt}
                    response=self.api.get_url(self.route,para)
                    response_msg=json.loads(response.text)
                    data=response_msg['data']
                    for j in data:
                        if j["messageId"]==messsgeid:
                            self.assertEqual(j["messageId"],messsgeid)
                            break
                        else:
                            continue
                else:
                    para = {"tenantId": body["tenantId"], "startDate": body["startDate"], "endDate": body["endDate"]}
                    response=self.api.get_url(self.route,para)
                    response_msg=self.api.check_response(response)
                    self.assertEqual(msg,response_msg[1])
        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testsearchdizan,"test_case_%s"%(cases[i]['case_name']),testsearchdizan.getsearchdizan(*args))
__generateTestCases()

if __name__ =="__main__":
    path = 'result_search.html'
    suit = unittest.TestLoader().loadTestsFromTestCase(testsearchdizan)
    with open(path, 'wb') as f:
        runner = HTMLTestRunner.HTMLTestRunner(stream=f, title='chat bot report', description='通过情况')
        runner.run(suit)






