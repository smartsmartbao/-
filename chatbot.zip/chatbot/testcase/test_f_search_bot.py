import unittest
import yaml
import requests
from apitest import *
from report import HTMLTestRunner
import os
path=os.path.join(BASE_PATH,'testcase_searchbot.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testsearchbo(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route = Yaml_Data['search_a_botinfo']['route']
        self.api = Request_Api()
    @staticmethod
    def getsearchbot(i,cases):
        def func(self):
            tenantid = cases[i]['tenantId']
            lang = cases[i]['lang']
            msg=cases[i]['msg']
            api_url='http://10.119.169.149:8081/api/v1/botInfo/'+tenantid+'/'+lang
            response=requests.get(api_url)
            response_msg=json.loads(response.text)
            if response.status_code!=404:
                if response_msg['data']!=None:
                    if len(response_msg['data'])>1:
                        self.assertEqual(msg,response_msg['msg'])
                    else:
                        self.assertEqual(tenantid,response_msg['data']['tenantId'])
                else:
                    self.assertEqual(msg, response_msg['msg'])
            else :
                self.assertEqual(msg, response_msg['message'])

        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testsearchbo, 'test_case_%s' % (cases[i]['case_name']), testsearchbo.getsearchbot(*args))
__generateTestCases()
if __name__ =='__main__':
    path = 'result_search.html'
    suit = unittest.TestLoader().loadTestsFromTestCase(testsearchbo)
    with open(path, 'wb') as f:
        runner = HTMLTestRunner.HTMLTestRunner(stream=f, title='Chat Bot Report', description='通过情况')
        runner.run(suit)


