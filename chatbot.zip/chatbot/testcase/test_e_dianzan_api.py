import unittest
from apitest import*
import yaml
import csv
from report import HTMLTestRunner
import os
path=os.path.join(BASE_PATH,'testcase_dizanbot.json')
answer=os.path.join(BASE_PATH,'answer.csv')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data = yaml.load(f)
class testdizanbot(unittest.TestCase):
    def setUp(self):
        self.route = Yaml_Data['dianzan_api']['route']
        self.api = Request_Api()
    @staticmethod
    def getdianzan(i,cases):
        def func(self):
            body=cases[i]['body']
            msg=cases[i]['msg']
            with open(answer,'r',encoding='utf-8') as f:
                csv_reader=csv.reader(f)
                for row in csv_reader:
                    if body['messageId']!=''and body['timestamp']!='':
                        body['messageId']=row[0]
                        body['timestamp']=row[1]
                        response = self.api.post_url(self.route, body)
                        response_msg=self.api.check_response(response)
                        self.assertEqual(msg,response_msg[1])
                    else:
                        response = self.api.post_url(self.route, body)
                        response_msg = self.api.check_response(response)
                        self.assertEqual(msg, response_msg[1])
                    break
        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    print(cases)
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testdizanbot,"test_case_%s"%(cases[i]['case_name']),testdizanbot.getdianzan(*args))
__generateTestCases()
if __name__ =="__main__":
    path='result_dizan.html'
    suit=unittest.TestLoader().loadTestsFromTestCase(testdizanbot)
    with open(path,'wb') as f:
        runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='chat bot report',description='通过情况')
        runner.run(suit)




