import unittest
from apitest import *
import yaml
from report import HTMLTestRunner
import os
path=os.path.join(BASE_PATH,'testcase_deletebot.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testdeletebo(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route=Yaml_Data['delete_a_botinfo']['route']
        self.api=Request_Api()
    @staticmethod
    def gettestdelete(i,cases):
        def func(self):
            tenantid=cases[i]['tenantId']
            lang=cases[i]['lang']
            msg=cases[i]['msg']
            response=self.api.delete_url(self.route,tenantid,lang)
            response_msg=json.loads(response.text)
            if response.status_code==404:
                self.assertEqual(msg,response_msg['message'])
            else:
                self.assertEqual(msg,response_msg['msg'])
        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testdeletebo,'test_case_%s'%(cases[i]['case_name']),testdeletebo.gettestdelete(*args))
__generateTestCases()
if __name__ =="__main__":
    path='result_delete.html'
    suit=unittest.TestLoader().loadTestsFromTestCase(testdeletebo)
    with open(path,'wb') as f:
        runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='Chat Bot Report',description='通过情况')
        runner.run(suit)


