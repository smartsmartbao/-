import unittest
import yaml
from apitest import *
from report import HTMLTestRunner
import os
import csv
import json
path=os.path.join(BASE_PATH,'testcase_tiwenbot.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testtiwenbot(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route=Yaml_Data['tiwen_api']['route']
        self.api=Request_Api()
    @staticmethod
    def gettiwenbot(i,cases):
        def func(self):
            body=cases[i]['body']
            msg=cases[i]['msg']
            b=[]
            with open(os.path.join(BASE_PATH,'answer.csv'),'a+',encoding='utf-8',newline='') as f :
                csv_file=csv.writer(f)
                response = self.api.post_url(self.route,body)
                response_text=json.loads(response.text)
                if response_text['msg']=='Request successful!':
                    sessionid=response_text['data']['answer']
                    answer=json.loads(sessionid)
                    b.append(answer['MessageId'])
                    b.append(str(response_text['data']['timestamp']))
                    csv_file.writerow(b)
                    self.assertEqual(msg,response_text['msg'])
                else:
                    self.assertEqual(msg,response_text['msg'])
        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    print(cases)
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testtiwenbot,"test_case_%s"%(cases[i]['case_name']),testtiwenbot.gettiwenbot(*args))
__generateTestCases()
if __name__ =="__main__":
    path='result_tiwen.html'
    suit=unittest.TestLoader().loadTestsFromTestCase(testtiwenbot)
    with open(path,'wb') as f:
        runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='chat bot report',description='通过情况')
        runner.run(suit)


