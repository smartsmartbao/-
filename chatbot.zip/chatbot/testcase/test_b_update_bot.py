import unittest
import yaml
from apitest import*
import yaml
from report import HTMLTestRunner
import requests
path=os.path.join(BASE_PATH,'testcase_updatebot.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testupdatebot(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route = Yaml_Data['update_botinfo']['route']
        self.api = Request_Api()
    @staticmethod
    def gettestupdate(i,cases):
        def func(self):
            body=cases[i]['body']
            msg=cases[i]['msg']
            response=self.api.put_url(self.route,body)
            response_msg=self.api.check_response(response)
            print(response_msg)
            self.assertEqual(msg,response_msg[1])
        return func
def __generateTestCases():
    api=Request_Api()
    case_text=api.read_json(path)
    cases=case_text['case']
    print(cases)
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testupdatebot,"test_case_%s"%(cases[i]['case_name']),testupdatebot.gettestupdate(*args))
__generateTestCases()
if __name__ =="__main__":
    path='result_update.html'
    suit=unittest.TestLoader().loadTestsFromTestCase(testupdatebot)
    with open(path,'wb') as f:
        runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='chat bot report',description='通过情况')
        runner.run(suit)




