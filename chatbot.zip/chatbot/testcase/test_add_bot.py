import unittest
import os
from apitest import*
import yaml
from report import HTMLTestRunner
import requests
path=os.path.join(BASE_PATH,'testcase_addbot.json')
with open(PATH,'r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class testaddbot(unittest.TestCase):
    maxDiff = None
    def setUp(self):
        self.route = Yaml_Data['add_botinfo']['route']
        self.api = Request_Api()
    @staticmethod
    def gettestadd(i,cases):
        def func(self):
            body=cases[i]['body']
            msg=cases[i]['msg']
            response=self.api.post_url(self.route,body)
            response_msg=self.api.check_response(response)
            print('testcase name is %s,msg is %s' % (cases[i]['case_name'], cases[i]['msg']))
            self.assertEqual(msg,response_msg[1])
        return func
def __generateTestCases():
    api=Request_Api()
    case_text = api.read_json(path)
    cases = case_text['case']
    print(cases)
    for i in range(len(cases)):
        args=[i,cases]
        setattr(testaddbot,'test_case_%s'%(cases[i]['case_name']),testaddbot.gettestadd(*args))

__generateTestCases()
if __name__ == "__main__":
    path='result.html'
    suit=unittest.TestLoader().loadTestsFromTestCase(testaddbot)
    with open(path,'wb') as f:
        runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='ChatBot Report',description='通过情况')
        runner.run(suit)




