import unittest
from report import HTMLTestRunner
from unittest import defaultTestLoader
case_path=r'testcase\.'
path='result_all.html'
discover=unittest.defaultTestLoader.discover(case_path,pattern="test*.py")
suit=unittest.TestSuite()
suit.addTest(discover)
with open(path,'wb') as f:
    runner=HTMLTestRunner.HTMLTestRunner(stream=f,title='chat bot report',description='通过情况')
    runner.run(suit)