import time
importos
tm=float(1554341510000/1000)
t=time.localtime(tm)
dt=time.strftime('%Y-%m-%d %H:%M:%S',t)
print(dt)