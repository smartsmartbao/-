import unittest
import yaml
from apitest import *
import requests
import pymysql
with open('config.yaml','r',encoding='utf-8') as f:
    Yaml_Data=yaml.load(f)
class add_case(unittest.TestCase):
    def setUp(self):
        self.route=Yaml_Data['add_botinfo']['route']
        self.api=Request_Api()
        self.botid='chatbot-cn-4590w4x4j0006h'
        self.accesskey_id='LTAI4zjITG3yApqd'
        self.accesskye_secret='LLNJv622EtZYcesMg8a9bUrfQvjvhz'
        self.url='https://chatbot.cn-shanghai.aliyuncs.com/'
        self.lang=['zh','en']
        self.body={

            'botId': self.botid,
            'botName':'aliyun',
            'tenantId':{},
            'accesskeyId':self.accesskey_id,
            'accesskeySecret':self.accesskye_secret,
            'url':self.url,
            'lang':{},
            'creator':'test'
        }
    def test_add_botinfo(self):#新增一条bot
        tenantid=input('请输入tenantid:')
        body=self.body
        body['tenantId']=tenantid
        for i in range(len(self.lang)):
            body['lang']=self.lang[i]
            response=self.api.post_url(self.route,body)
            msg=self.api.check_response(response)
            response_msg=msg[1]
            xlsx_msg = self.api.read_xlsx(response,Yaml_Data['error'],'addapi')
            self.assertEqual(response_msg,xlsx_msg)
    def test_add_repeat_botinfo(self):#新增重复的bot
        tenantid = input('请输入tenantid:')
        body=self.body
        for i in range(len(self.lang)):
            body['lang'] = self.lang[i]
            body['tenantId'] = tenantid
            response = self.api.post_url(self.route, body)
            msg=self.api.check_response(response)
            response_msg=msg[1]
            xlsx_msg = self.api.read_xlsx(response,Yaml_Data['error'],'addapi')
            self.assertEqual(response_msg,xlsx_msg)
    def test_empty_ternatid(self):#新增一条tenatid为空的bot
        body=self.body
        body['lang']='zh'
        body['tenantId']=''
        response=self.api.post_url(self.route,body)
        msg=self.api.check_response(response)
        response_msg=msg[1]
        xlsx_msg=self.api.read_xlsx(response,Yaml_Data['error'],'addapi')
        self.assertEqual(response_msg,xlsx_msg)
    def test_no_ternatid(self):#新增一条tenatid为空的bot
        body=self.body
        body['lang']='zh'
        del body['tenantId']
        response=self.api.post_url(self.route,body)
        msg=self.api.check_response(response)
        response_msg=msg[1]
        xlsx_msg=self.api.read_xlsx(response,Yaml_Data['error'],'addapi')
        self.assertEqual(response_msg,xlsx_msg)
if __name__ == '__main__':
    unittest.main()